#include "stdafx.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "ElevatorLib.h"

/**********************************************
 **********************************************/
void StateIdle(int *state)//���غ���
{
	int floor; bool up;
	floor = IdleWhatFloorToGoTo(&up);
	if (floor > 0 && up)
	{
		SetMotorPower(1);
		*state = MovingUp;
		
	}
	else if (floor>0&&!up)
	{
		SetMotorPower(-1);
		*state = MovingDown;
	}
	else if (GetOpenDoorLight())
	{
		SetOpenDoorLight(0);
		SetDoor(GetNearestFloor(), 1);
		*state = DoorOpen;
	}
	else if (GetCallLight(floor, up))
	{
		SetCallLight(GetNearestFloor(), up, 0);
		SetDoor(GetNearestFloor(), 1);
		*state = DoorOpen;
	}
	else if (GetCloseDoorLight())
	{
		SetCloseDoorLight(0);
		return;
	}
}
void StateMovingUp(int *state)
{
	
	int floor = GoingUpToFloor();
	if (fabs(GetFloor() - floor) < Lib_FloorTolerance)
	{
		SetMotorPower(0);
		SetDoor(GetNearestFloor(), 1);
		SetCallLight(GetNearestFloor(), 1 || 0, 0);
		SetPanelFloorLight(GetNearestFloor(), 0);
	  *state = DoorOpen;
	}
	else if (GetOpenDoorLight() || GetCloseDoorLight())
	{
		SetOpenDoorLight(0);
		SetCloseDoorLight(0);
	}
	  
}
void StateMovingDown(int *state)
{

	int floor; bool up;
	floor = GoingDownToFloor();
	up = GetCallLight(floor, 1);
	if (fabs(GetFloor() - floor) < Lib_FloorTolerance)
	{
		SetMotorPower(0);

		SetDoor(GetNearestFloor(), 1);
		*state = DoorOpen;}
	else if (GetOpenDoorLight() || GetCloseDoorLight())
	{
		SetOpenDoorLight(0);
		SetCloseDoorLight(0);
	}


}
void StateDoorOpen(int *state)
{

	int floor = GetFloor();
	//CancelTo1Floor();
	if (GetCloseDoorLight())
	{
		SetDoor(floor, 0);
		SetCloseDoorLight(0);
		
		*state = DoorClosing;
		

	}
	else if (IsDoorOpen(floor))
	{
		SetDoor(floor, 0);
		*state = DoorClosing;
	}
	else if (GetOpenDoorLight())
		SetOpenDoorLight(0);

}

void StateDoorClosing(int *state)
{
	if (GetOpenDoorLight())
	{
		SetDoor(GetNearestFloor(), 1);
		SetOpenDoorLight(0);
		*state = DoorOpen;
	}
	else if (GetCloseDoorLight())
	{
		SetCloseDoorLight(0);
	}
	else if (IsBeamBroken())
	{
		SetDoor(GetNearestFloor(), 1);
		*state = DoorOpen;
	}
	else if (IsDoorClosed(GetNearestFloor()))
	{
		SetOpenDoorLight(0);
		*state = Idle;
	}

}
/***********************************************
 * ״̬����ÿ��һ��ʱ��(�磬100ms)������һ�Σ��ɼ�ϵͳ������״̬
 ***********************************************/
void main_control(int *state)
{  
    if(IsElevatorRunning())  // ��������
    {
		switch(*state)
		{
		case Idle:
			// һ��ʱ���޶������Զ���һ¥
			if(GetNearestFloor() !=1 ) {
				AutoTo1Floor();
			}
			StateIdle(state);
			break;
		case MovingUp:
			CancelTo1Floor(); // ����״̬��ȡ���Զ���һ¥
			StateMovingUp(state);
			break;
		case MovingDown:
			CancelTo1Floor();
			StateMovingDown(state);
			break;
		case DoorOpen:
			CancelTo1Floor();
			StateDoorOpen(state);
			break;
		case DoorClosing:
			CancelTo1Floor();
			StateDoorClosing(state);
			break;
		default:
			printf("��״̬!!!\n");  
		}
    }
}
